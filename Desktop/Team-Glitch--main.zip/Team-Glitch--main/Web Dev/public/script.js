function Compile1(){
    var imageChange=document.getElementById("btn1").src="output_1.jpg";
}

function Compile2(){
    var imageChange=document.getElementById("btn2").src="output_2.jpg";
}

function Compile3(){
    var imageChange=document.getElementById("btn3").src="output_3.jpg";
}